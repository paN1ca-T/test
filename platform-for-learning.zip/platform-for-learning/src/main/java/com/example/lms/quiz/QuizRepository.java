package com.example.lms.quiz;

import com.example.lms.course.CourseModule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface QuizRepository extends JpaRepository<Quiz, Long> {
    Optional<Quiz> findByModule(CourseModule module);
}


