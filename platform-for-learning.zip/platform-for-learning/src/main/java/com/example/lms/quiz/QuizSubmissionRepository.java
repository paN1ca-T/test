package com.example.lms.quiz;

import com.example.lms.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuizSubmissionRepository extends JpaRepository<QuizSubmission, Long> {
    List<QuizSubmission> findByQuiz(Quiz quiz);
    List<QuizSubmission> findByStudent(User student);
}


