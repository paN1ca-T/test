package com.example.lms.lesson;

import com.example.lms.course.CourseModule;
import com.example.lms.common.repository.ModuleRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/lessons")
public class LessonController {

    private final LessonService lessonService;
    private final ModuleRepository moduleRepository;

    public LessonController(LessonService lessonService, ModuleRepository moduleRepository) {
        this.lessonService = lessonService;
        this.moduleRepository = moduleRepository;
    }

    @GetMapping
    public List<LessonDto> findAll() { return lessonService.findAll().stream().map(LessonMapper::toDto).collect(Collectors.toList()); }

    @GetMapping("/{id}")
    public LessonDto getById(@PathVariable Long id) { return LessonMapper.toDto(lessonService.getById(id)); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LessonDto create(@Valid @RequestBody LessonRequest request) {
        CourseModule module = moduleRepository.findById(request.getModuleId()).orElseThrow();
        Lesson created = lessonService.create(LessonMapper.fromRequest(request, module));
        return LessonMapper.toDto(created);
    }

    @PutMapping("/{id}")
    public LessonDto update(@PathVariable Long id, @Valid @RequestBody LessonRequest request) {
        Lesson existing = lessonService.getById(id);
        CourseModule module = moduleRepository.findById(request.getModuleId()).orElseThrow();
        LessonMapper.updateEntity(existing, request, module);
        return LessonMapper.toDto(lessonService.update(id, existing));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { lessonService.delete(id); }
}


