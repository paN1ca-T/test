package com.example.lms.question;

public enum QuestionType {
    SINGLE_CHOICE,
    MULTIPLE_CHOICE
}



