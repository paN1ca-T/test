package com.example.lms.common.repository;

import com.example.lms.course.Course;
import com.example.lms.course.CourseModule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ModuleRepository extends JpaRepository<CourseModule, Long> {
    List<CourseModule> findByCourseOrderByOrderIndexAsc(Course course);
}


