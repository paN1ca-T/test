package com.example.lms.user;

public enum UserRole {
    STUDENT,
    TEACHER,
    ADMIN
}



