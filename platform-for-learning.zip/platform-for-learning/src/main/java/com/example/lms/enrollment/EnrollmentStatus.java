package com.example.lms.enrollment;

public enum EnrollmentStatus {
    ACTIVE,
    COMPLETED,
    CANCELLED
}



