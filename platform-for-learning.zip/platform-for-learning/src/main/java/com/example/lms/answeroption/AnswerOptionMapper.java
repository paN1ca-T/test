package com.example.lms.answeroption;

import com.example.lms.question.Question;

public class AnswerOptionMapper {
    public static AnswerOptionDto toDto(AnswerOption o) {
        AnswerOptionDto dto = new AnswerOptionDto();
        dto.setId(o.getId());
        dto.setQuestionId(o.getQuestion() != null ? o.getQuestion().getId() : null);
        dto.setText(o.getText());
        dto.setCorrect(o.isCorrect());
        return dto;
    }

    public static AnswerOption fromRequest(AnswerOptionRequest request, Question q) {
        AnswerOption o = new AnswerOption();
        o.setQuestion(q);
        o.setText(request.getText());
        o.setCorrect(request.isCorrect());
        return o;
    }
}


